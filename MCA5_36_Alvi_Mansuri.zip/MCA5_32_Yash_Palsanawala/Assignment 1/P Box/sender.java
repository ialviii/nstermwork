import bsr.*;
/*A code from www.bipinrupadiya.com*/
public class sender
{
 public static void main(String args[])throws Exception
 {
  
  String myString="BipinRupadiya";
  /*
  // read data from user 
  Scanner sc=new Scanner(System.in);
  System.out.println("Enter String(only alphabets allowed) :");
  myString=sc.next();
  
  */
  
  PBOX obj =new PBOX();
  
  String encryptedString=obj.doEncryption(myString);
  System.out.println("\nEncryted String : "+encryptedString);
  MySocket m = new MySocket();
  m.sendFrame(encryptedString);
 }

}