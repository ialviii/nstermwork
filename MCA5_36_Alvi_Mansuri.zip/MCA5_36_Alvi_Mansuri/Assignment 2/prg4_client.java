import java.io.*;
import java.util.*;
import java.net.*;
class prg4_client
{
	public static void main(String args[])throws Exception
	{
		Scanner sc=new Scanner(System.in);
		String numbers="";
		System.out.print("Enter set of numbers you want to send :");
		String num=sc.nextLine();
		Socket s=new Socket("127.0.0.1",1234);
		DataOutputStream dos=new DataOutputStream(s.getOutputStream());
		dos.writeUTF(num);
		DataInputStream dis=new DataInputStream(s.getInputStream());
		String server_msg=dis.readUTF();
		System.out.println(server_msg);
		s.close();
		
	}
}
