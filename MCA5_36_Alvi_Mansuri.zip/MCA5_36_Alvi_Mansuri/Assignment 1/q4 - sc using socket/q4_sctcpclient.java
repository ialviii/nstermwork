import java.util.*;
import java.io.*;
import java.net.Socket;
import java.net.SocketException;

public class q4_sctcpclient
{
	public static void main(String args[]) throws IOException
	{
		Scanner sc=new Scanner(System.in);
		Socket sk=new Socket("127.0.0.1",1234);
		DataOutputStream dos=new DataOutputStream(sk.getOutputStream());
		String s;
		System.out.println("Enter String to be Encrypted: ");
		s=sc.nextLine();
		System.out.println("Enter Key: ");
		int k=sc.nextInt();
		BufferedWriter bw=new BufferedWriter(new FileWriter("key.txt"));
		bw.write(k+"");
		bw.close();
		String es=encrypt(s,k);
		dos.writeBytes(es+"\n");
		System.out.println("Encrypted Text: "+es+" successfully sent!");
	}
	
	public static String encrypt(String s, int k)
	{
		StringBuilder sb=new StringBuilder();
		char c;
		for(int i=0; i<s.length(); i++)
		{
			if((s.charAt(i)>='a' && s.charAt(i)<='z') || (s.charAt(i)>='A' && s.charAt(i)<='Z'))
			{
				if(s.charAt(i)<=96+k && s.charAt(i)>=97)
				{
					c=(char)(s.charAt(i)+(26-k));
					sb.append(c);
					continue;					
				}
				else if(s.charAt(i)<=(64+k))
				{
					c=(char)(s.charAt(i)+(26-k));
					sb.append(c);
					continue;
				}
				c=(char)(s.charAt(i)-k);
				sb.append(c);
				continue;
			}
			else if(s.charAt(i)>='0' && s.charAt(i)<='9')
			{
				if(s.charAt(i)<=47+k)
				{
					c=(char)(s.charAt(i)+(10-k));
					sb.append(c);
					continue;					
				}
				c=(char)(s.charAt(i)-k);
				sb.append(c);
				continue;
			}
			sb.append(s.charAt(i));
		}
		return sb.toString();
	}
}
